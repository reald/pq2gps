Icons taken from http://gsak.net/board/index.php?showtopic=7033 with
friendly permission of Kaylin Bradley. 